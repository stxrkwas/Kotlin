package lista2

//Exercícios de fixação - Kotlin

//Exercício 2

//Iniciando a classe principal Produto
class Produto(

    //Declaração de variáveis
    private val nome: String = "",
    private val preco: Double,
    private val quantidade: Double)

{

    //Iniciando o método Desconto
    fun desconto(){

        if(quantidade == 10.0){

            println("Não há desconto")
        }

        else if(quantidade in 11.0..20.0){

            //Cálculo do desconto
            val desconto: Double = preco - (preco * 0.1)

            //Saída de dados
            println("Desconto: 10%")
            println("O preço com desconto é: R$$desconto")
        }

        else if(quantidade in 21.0..50.0){

            //Cálculo do desconto
            val desconto: Double = preco - (preco * 0.2)

            //Saída de dados
            println("Desconto: 20%")
            println("O preço com desconto é: R$ $desconto")

        }

        else if(quantidade > 50.0){

            //Cálculo do desconto
            val desconto: Double = preco - (preco * 0.25)

            //Saída de dados
            println(message = "Desconto: 25%")
            println(message ="O preço com desconto é: R$ $desconto")
        }

    }//Finalizando o método Desconto

}//Finalizando a classe Produto

//Iniciando a função main
fun main(){

    val product = Produto("Samsung Galaxy A10", 4000.00, 15.0)
    product.desconto()

}//Finalizando a função main
