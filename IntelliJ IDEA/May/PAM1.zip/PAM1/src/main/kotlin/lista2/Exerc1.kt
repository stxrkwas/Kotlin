package lista2

//Exercícios de fixação - Kotlin

//Exercício 1

//Iniciando a função main
fun main(args: Array<String>){

    //Saída de mensagem no console
    println("Tuesday");
    println("Wednesday");
    println("Thursday");
    println("Friday");
    println("Monday");


}//Finalizando a função main