package lista2

/*Exercício 2*/

/*Importação de classe*/
import java.util.Scanner

/*Iniciando a classe principal*/
class CalcNota{

    /*Cria uma instância que recebe entrada da entrada padrão (teclado)*/
    private val reader = Scanner(System.`in`)

    /*Iniciando método para receber as notas e calcular a média*/
    fun calculoMedia() {

        /*Nota 1:

        Exibindo mesnagem que instrui o usuário a digitar a nota: */
        println("Insira a primeira nota: ")

        /*Declaração de variável para a entrada do valor. A função .nextFloat() converte a String para Float. */
        val nota1 = reader.nextFloat()


        /*Nota 2:

        Exibindo mesnagem que instrui o usuário a digitar a nota: */
        println("Insira a segunda nota: ")

        /*Declaração de variável para a entrada do valor. A função .nextFloat() converte a String para Float. */
        val nota2 = reader.nextFloat()


        /*Nota 3:

        Exibindo mesnagem que instrui o usuário a digitar a nota: */
        println("Insira a terceira nota: ")

        /*Declaração de variável para a entrada do valor. A função .nextFloat() converte a String para Float. */
        val nota3 = reader.nextFloat()


        /*Calculo da média:*/
        val media: Float = ((nota1 + nota2 + nota3) / 3)

        if(media in 6.0.. 10.0){

            println("Média: $media")
            println("Aluno aprovado!")

        }

        else if(media in 4.0..6.0){

            println("Média: $media")
            println("Aluno em verificação suplementar")

        }

        else if(media in 0.0..4.0){

            println("Média: $media")
            println("Aluno reprovado!")

        }

    }//Finalizando o método calculoMedia

}

fun main(){

    val nota = CalcNota()
    nota.calculoMedia()

}