package lista1

/*Importação de classe*/
import java.util.Scanner

/*Iniciando o método main*/
fun main(){

    /*Cria uma instância que recebe entrada da entrada padrão (teclado)*/
    val reader = Scanner(System.`in`)

    //Exibindo mensagem instruindo o usuário a inserir um número:
    println("Insira um número: ")

    //Variável que vai receber o valor e convertê-lo para Int
    var num = reader.nextInt()

    //Exibindo mensagem antes de mostar a tabuada:
    println("")
    println("Tabuada do número $num: ")
    println("")

    /*Estrutura de repetição para mostrar a multiplicação de um número enquanto ele estiver entre 0 e 10.*/
    for(x in 0..10){

        val tabuada: Int = (num * x)
        println("$num x $x = $tabuada")

    }//Finalizando for

}//Finalizando o método main

/*Exercício 2: Escreva um programa que calcule e imprima a tabuada do 8 (1 a 10).

Código:

/*Iniciando o método main*/
fun main(){

   println("Tabuada do número 8)
   println("")

   for(i in 0..10){

       val tabuada: Int = (num * x)
        println("$num x $x = $tabuada")

    }//Finalizando for

}//Finalizando o método main*/

