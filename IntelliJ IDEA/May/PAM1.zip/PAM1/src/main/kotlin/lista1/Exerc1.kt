package lista1

/*Exercício 1 - Lista 1*/

//Iniciando a classe principal*/
class CalculoSalario(

    /*Declaração de variáveis*/
    private var salariof: Double,
    private var comissaof: Double,
    private var vendascar: Int,
    private var totalven: Int)

{
    /*Iniciando função para calcular o salário final*/
    fun salarioFinal(){

        /*Declaração de variável para cálculo*/
        val salariofinal = salariof + comissaof + (totalven * 0.05)

        /*Retornando o resultado do cálculo*/
        print(message = "Salário final: R$$salariofinal")

    }/*Finalizando a função salarioFinal*/

    fun saidaDados(){

        /*Saída de dados*/
        println(message = "Informações: ")
        println(message = "")
        println(message = "Carros vendidos: $vendascar")
        println(message = "Valor total de vendas: R$$totalven")
        println(message = "Salário fixo: R$$salariof")
        println(message = "Comissão fixa: R$$comissaof")
        println("")
    }
}
/*Iniciando a função main*/
fun main(){

    /*Declaração de variáveis*/
    var salary = CalculoSalario(1800.00, 200.00, 5, 200000)
    salary.saidaDados()
    salary.salarioFinal()

}