package Whaaat

//Maria Luiza Passo Silva

//Exercício 2

//Importação de classe
import java.util.Scanner

//Iniciando função main
fun main(){

    //Cria uma instância que recebe entrada da entrada padrão (teclado)
    val reader = Scanner(System.`in`)

    //Lado A:

    //Exibindo mensagens para o usuário inserir o valor do lado do triângulo
    println("Insira o valor do lado A: ")
    //Declaração de variável para a entrada do valor. A função readLine() lê a entrada do usuário.
    var a = readLine()!!
    //A função .toDouble() converte a String para Double
    var ladoA: Double = a.toDouble()


    //Lado B:

    //Exibindo mensagens para o usuário inserir o valor do lado do triângulo
    println("Insira o valor do lado B: ")
    //Declaração de variável para a entrada do valor. A função readLine() lê a entrada do usuário.
    var b = readLine()!!
    //A função .toDouble() converte a String para Double
    var ladoB: Double = b.toDouble()


    //Lado C:

    //Exibindo mensagens para o usuário inserir o valor do lado do triângulo
    println("Insira o valor do lado C: ")
    //Declaração de variável para a entrada do valor. A função readLine() lê a entrada do usuário.
    var c = readLine()!!
    //A função .toDouble() converte a String para Double
    var ladoC: Double = c.toDouble()


    //Estrutura de decisão para descobrir qual tipo de triângulo é:
    if (ladoA == ladoB && ladoB == ladoC){
        println("Triângulo Equilátero")
    }//Finalizando if

    else if (ladoA == ladoB || ladoB == ladoC || ladoC == ladoA){
        println("Triângulo Isósceles")
    }//Finalizando else if

    else if (ladoA != ladoB && ladoA!= ladoC && ladoB != ladoC){
        println("Triângulo Escaleno")
    }//Finalizando else if

}//Finalizando função main