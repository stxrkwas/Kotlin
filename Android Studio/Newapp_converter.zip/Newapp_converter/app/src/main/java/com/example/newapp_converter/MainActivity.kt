package com.example.newapp_converter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton

class MainActivity : AppCompatActivity() {

    lateinit var editText: EditText
    lateinit var celciusRadio: RadioButton
    lateinit var fahreinheitRadio: RadioButton
    lateinit var converterButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.valorTemp) as EditText

        celciusRadio = findViewById(R.id.celciusRadio) as RadioButton

        fahreinheitRadio = findViewById(R.id.fahreinheitRadio) as RadioButton

        converterButton = findViewById(R.id.converterButton) as Button
    }
}